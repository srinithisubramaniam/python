from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/ticketchecking'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
@app.route("/new")
def index():
	return render_template("index.html")
@app.route("/a")
def selection():
   return render_template("selection.html")
@app.route("/b")
def ttr():
   return render_template("ttr.html")
@app.route("/c")
def ttrview():
   return render_template("ttrview.html")
@app.route("/d")
def check():
   return render_template("check.html")
@app.route("/e")
def checkdetail():
   return render_template("checkdetail.html")
@app.route("/f")
def allview():
   return render_template("allview.html")
@app.route("/g")
def inspector():
   return render_template("inspector.html")
@app.route("/h")
def insview():
   return render_template("insview.html")   
@app.route("/i")
def chief():
   return render_template("chief.html")
@app.route("/j")
def chiefview():
   return render_template("chiefview.html")
@app.route("/k")
def minister():
   return render_template("minister.html")
@app.route("/l")
def ministerview():
   return render_template("ministerview.html")
@app.route("/admin")
def admin():
   return render_template("admin.html")
@app.route("/users")
def users():
   return render_template("users.html",register=register.query.all())
@app.route("/users2")
def users2():
   return render_template("users2.html",insregister=insregister.query.all())
@app.route("/users3")
def users3():
   return render_template("users3.html",chiefregister=chiefregister.query.all())
@app.route("/users4")
def users4():
   return render_template("users4.html",miniregister=miniregister.query.all())
class register(db.Model):
	id = db.Column('demo', db.Integer, primary_key = True)
	Name = db.Column(db.String(100))
	Address = db.Column(db.String(100))
	Number = db.Column(db.String(50))
	EmailAddress = db.Column(db.String(80))
	UserName = db.Column(db.String(100))
	Password = db.Column(db.String(30))
	ConfirmPassword = db.Column(db.String(30))
	def __init__(self, Name, Address, Number, EmailAddress, UserName, Password, ConfirmPassword):
		self.Name = Name
		self.Address = Address
		self.Number = Number
		self.EmailAddress = EmailAddress
		self.UserName = UserName
		self.Password = Password
		self.ConfirmPassword = ConfirmPassword
	@app.route('/ttrview', methods = ['GET', 'POST'])
	def new1():
		if request.method == 'POST':
			if not request.form['Name'] or not request.form['Address'] or not request.form['Number'] or not request.form['EmailAddress'] or not request.form['UserName'] or not request.form['Password'] or not request.form['ConfirmPassword']:
				flash('Please enter all the fields', 'error')
			else:
				demo = register(request.form['Name'], request.form['Address'], request.form['Number'], request.form['EmailAddress'], request.form['UserName'], request.form['Password'], request.form['ConfirmPassword'])
				db.session.add(demo)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('ttrview'))
		return render_template('ttr.html')
@app.route('/admin1', methods = ['POST','GET'])
def admin1():
	if request.method=='GET':
		return render_template('index.html')
	UserName = request.form['UserName']
	Password = request.form['Password']
	demo=register.query.filter_by(UserName=UserName,Password=Password).first()
	if request.form['Password'] == 'admin' and request.form['UserName'] == 'admin':
		return render_template("admin.html")
	if demo is None:
		return render_template("index.html")
	else:
		return render_template("ttrview.html")
class insregister(db.Model):
	id = db.Column('demo1', db.Integer, primary_key = True)
	Name = db.Column(db.String(100))
	Email = db.Column(db.String(100))
	Password = db.Column(db.String(50))
	ConfirmPassword = db.Column(db.String(30))
	def __init__(self, Name, Email, Password, ConfirmPassword):
		self.Name = Name
		self.Email = Email
		self.Password = Password
		self.ConfirmPassword = ConfirmPassword
	@app.route('/insview', methods = ['GET', 'POST'])
	def new2():
		if request.method == 'POST':
			if not request.form['Name'] or not request.form['Email'] or not request.form['Password']  or not request.form['ConfirmPassword']:
				flash('Please enter all the fields', 'error')
			else:
				demo1 = insregister(request.form['Name'], request.form['Email'], request.form['Password'], request.form['ConfirmPassword'])
				db.session.add(demo1)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('insview'))
		return render_template('inspector.html')
class chiefregister(db.Model):
	id = db.Column('demo2', db.Integer, primary_key = True)
	Name = db.Column(db.String(100))
	City = db.Column(db.String(100))
	Email = db.Column(db.String(100))
	Password = db.Column(db.String(50))
	ConfirmPassword = db.Column(db.String(30))
	def __init__(self, Name, City, Email, Password, ConfirmPassword):
		self.Name = Name
		self.City = City
		self.Email = Email		
		self.Password = Password
		self.ConfirmPassword = ConfirmPassword
	@app.route('/chiefview', methods = ['GET', 'POST'])
	def new3():
		if request.method == 'POST':
			if not request.form['Name'] or not request.form['City'] or not request.form['Email'] or not request.form['Password']  or not request.form['ConfirmPassword']:
				flash('Please enter all the fields', 'error')
			else:
				demo2 = chiefregister(request.form['Name'], request.form['City'], request.form['Email'], request.form['Password'], request.form['ConfirmPassword'])
				db.session.add(demo2)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('chiefview'))
		return render_template('chief.html')
class miniregister(db.Model):
	id = db.Column('demo4', db.Integer, primary_key = True)
	Name = db.Column(db.String(100))
	Password = db.Column(db.String(50))
	Confirmpassword = db.Column(db.String(30))
	def __init__(self, Name, Password, Confirmpassword):
		self.Name = Name
		self.Password = Password
		self.Confirmpassword = Confirmpassword
	@app.route('/ministerview', methods = ['GET', 'POST'])
	def new4():
		if request.method == 'POST':
			if not request.form['Name'] or not request.form['Password']  or not request.form['Confirmpassword']:
				flash('Please enter all the fields', 'error')
			else:
				demo4 = miniregister(request.form['Name'], request.form['Password'], request.form['Confirmpassword'])
				db.session.add(demo4)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('ministerview'))
		return render_template('minister.html')
class ttrview(db.Model):
	id = db.Column('demo4', db.Integer, primary_key = True)
	TrainId = db.Column(db.String(100))
	Coach = db.Column(db.String(100))
	TicketNo = db.Column(db.String(100))
	def __init__(self, TrainId, Coach, TicketNo):
		self.TrainId = TrainId
		self.Coach = Coach
		self.TicketNo = TicketNo		
	@app.route('/ttrview', methods = ['GET', 'POST'])
	def tv():
		if request.method == 'POST':
			if not request.form['TrainId'] or not request.form['Coach'] or not request.form['TicketNo']:
				flash('Please enter all the fields', 'error')
			else:
				demo4 = ttrview(request.form['TrainId'], request.form['Coach'], request.form['TicketNo'])
				db.session.add(demo4)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('ttr'))
		return render_template('ttrview.html')
class insview(db.Model):
	id = db.Column('demo4', db.Integer, primary_key = True)
	TrainId = db.Column(db.String(100))
	Coach = db.Column(db.String(100))
	def __init__(self, TrainId, Coach):
		self.TrainId = TrainId
		self.Coach = Coach
	@app.route('/insview', methods = ['GET', 'POST'])
	def iv():
		if request.method == 'POST':
			if not request.form['TrainId'] or not request.form['Coach']:
				flash('Please enter all the fields', 'error')
			else:
				demo4 = ttrview(request.form['TrainId'], request.form['Coach'])
				db.session.add(demo4)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('inspector'))
		return render_template('insview.html')
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
