from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/ticket'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
@app.route("/ticket")
def new():
	return render_template("side.html")
@app.route("/status")
def status():
	return render_template("status.html")
@app.route("/online")
def online():
	return render_template("online.html")
@app.route("/eline")
def eline():
	return render_template("eline.html")

@app.route("/all")
def newall():
	return render_template("all.html",pasregister=pasregister.query.all())

@app.route("/login")
def newlogin():
	return render_template("login.html")
@app.route("/newlogin")
def newlogin1():
	return render_template("newlogin.html")
@app.route("/passengerdetail")
def passengerdetail():
	return render_template("passengerdetail.html")
@app.route("/paid")
def paid():
	return render_template("paid.html")

@app.route("/compview")
def compview():
	return render_template("compview.html",complaint=complaint.query.all())
@app.route("/pnr")
def pnr():
	return render_template("pnr.html")
@app.route("/reservation")
def reservation():
   return render_template("reservation.html")
@app.route("/trainres")
def trainres():
   return render_template("trainres.html")
@app.route("/con")
def contact():
	return render_template("contact.html")
@app.route("/trainmenu")
def trainmenu():
	return render_template("trainmenu.html")
@app.route("/cpp")
def cpp():
   return render_template("cpp.html")
@app.route("/cpp1")
def cpp1():
   return render_template("cpp1.html")
@app.route("/regttr")
def ttr():
   return render_template("ttr.html")
@app.route("/allot")
def allot():
   return render_template("allot.html")
@app.route("/c")
def ttrview():
   return render_template("ttrview.html",register=register.query.all())
@app.route("/d")
def check():
   return render_template("check.html")
@app.route("/train1det")
def train1det():
   return render_template("train1det.html")
@app.route("/e")
def checkdetail():
   return render_template("checkdetail.html")
@app.route("/alloted")
def alloted():
   return render_template("alloted.html")

@app.route("/verify")
def verify():
   return render_template("verifylist.html",pasregister=pasregister.query.filter_by(dis='1'))

@app.route("/f")
def allview():
   return render_template("allview.html")
@app.route("/inspector")
def inspector():
   return render_template("inspector.html")
@app.route("/insview")
def insview():
   return render_template("insview.html")   
@app.route("/i")
def chief():
   return render_template("chief.html")
@app.route("/j")
def chiefview():
   return render_template("chiefview.html")
@app.route("/k")
def minister():
   return render_template("minister.html")
@app.route("/l")
def ministerview():
   return render_template("ministerview.html")
@app.route("/pasen")
def pasen():
   return render_template("pasenger.html")
@app.route("/t1")
def t1():
   return render_template("t1.html")

@app.route("/pasen1")
def pasen1():
   return render_template("pasenger1.html")
@app.route("/pasen2")
def pasen2():
   return render_template("pasenger2.html")
@app.route("/fine")
def complaint():
   return render_template("fine.html")
@app.route("/users")
def users():
   return render_template("users.html",register=register.query.all())
@app.route("/onlineview")
def onlinebook():
   return render_template("onlineview.html",onlinebook=onlinebook.query.filter_by(Date='30-11-2017'))
@app.route("/elineview")
def elinebook():
   return render_template("elineview.html",elinebook1=elinebook1.query.all())

@app.route("/users2")
def users2():
   return render_template("users2.html",insregister=insregister.query.all())

@app.route("/checkpas/<int:name>")
def checkpas(name):
   return render_template("checkpas.html",pasregister=pasregister.query.filter_by(PNRNo='%d'%name))
@app.route("/checktrain1/<int:name>")
def checktrain1(name):
   return render_template("checktrain1.html",pasregister1=pasregister1.query.filter_by(TicketNo='%d'%name))
@app.route("/searchpas/<int:names>")
def searchpas(names):
   return render_template("searchpas.html",pasregister=pasregister.query.filter_by(TrainId='%d'%names))
class register(db.Model):
	id = db.Column('demo', db.Integer, primary_key = True)
	UserName = db.Column(db.String(100))
	Age = db.Column(db.String(100))
	Email = db.Column(db.String(80))
	Password = db.Column(db.String(30))
	ConfirmPassword = db.Column(db.String(30))
	Phoneno = db.Column(db.String(30))
	def __init__(self, UserName, Age, Email, Password, ConfirmPassword, Phoneno):
		self.UserName = UserName
		self.Age = Age
		self.Email = Email
		self.Password = Password
		self.ConfirmPassword = ConfirmPassword
		self.Phoneno = Phoneno
	@app.route('/trainmenu', methods = ['GET', 'POST'])
	def new1():
		if request.method == 'POST':
			if not request.form['UserName'] or not request.form['Age'] or not request.form['Email'] or not request.form['Password'] or not request.form['ConfirmPassword'] or not request.form['Phoneno']:
				flash('Please enter all the fields', 'error')
			else:
				demo = register(request.form['UserName'], request.form['Age'], request.form['Email'], request.form['Password'], request.form['ConfirmPassword'], request.form['Phoneno'])
				db.session.add(demo)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('trainmenu'))
		return render_template('newlogin.html')
@app.route('/loginn', methods=['POST','GET'])
def loginn():
	if request.method=='GET':
		return render_template('newlogin.html')
	UserName = request.form['UserName']
	Password = request.form['Password']
	demo=register.query.filter_by(UserName=UserName,Password=Password).first()
	demo1=insregister.query.filter_by(UserName=UserName,Password=Password).first()
	if request.form['Password'] == 'admin' and request.form['UserName'] == 'admin':
		return render_template("admin.html")
	if demo is not None:
		return redirect(url_for('trainmenu',name=UserName))
	elif demo1 is not None:
		return redirect(url_for('cpp1',name=UserName))
	else:
		return render_template("index.html")	

		
@app.route('/check_view', methods=['POST','GET'])
def check_view():
	if request.method=='POST':
		check = request.form['check']
		return redirect(url_for('checkpas',name=check))
@app.route('/check_insview', methods=['POST','GET'])
def check_insview():
	if request.method=='POST':
		search = request.form['search']
		return redirect(url_for('searchpas',names=search))
@app.route('/check_train1', methods=['POST','GET'])
def check_train1():
	if request.method=='POST':
		check = request.form['check']
		return redirect(url_for('checktrain1',name=check))	
class insregister(db.Model):
	id = db.Column('demo1', db.Integer, primary_key = True)
	Name = db.Column(db.String(100))
	Email = db.Column(db.String(100))
	UserName = db.Column(db.String(100))	
	Password = db.Column(db.String(50))
	ConfirmPassword = db.Column(db.String(30))
	def __init__(self, Name, Email, UserName, Password, ConfirmPassword):
		self.Name = Name
		self.Email = Email
		self.UserName = UserName
		self.Password = Password
		self.ConfirmPassword = ConfirmPassword
	@app.route('/insview', methods = ['GET', 'POST'])
	def new2():
		if request.method == 'POST':
			if not request.form['Name'] or not request.form['Email'] or not request.form['UserName'] or not request.form['Password']  or not request.form['ConfirmPassword']:
				flash('Please enter all the fields', 'error')
			else:
				demo1 = insregister(request.form['Name'], request.form['Email'], request.form['UserName'], request.form['Password'], request.form['ConfirmPassword'])
				db.session.add(demo1)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('inspector'))
		return render_template('insview.html')

class pasregister(db.Model):
	id = db.Column('passenger', db.Integer, primary_key = True)
	PNRNo = db.Column(db.String(100))
	TrainId = db.Column(db.String(100))
	PassengerName = db.Column(db.String(100))
	Gender = db.Column(db.String(100))
	Age = db.Column(db.String(30))
	Parcel = db.Column(db.String(30))
	PhoneNo = db.Column(db.String(30))
	status = db.Column(db.String(30))
	dis = db.Column(db.Integer,default=1)
	def __init__(self, PNRNo, TrainId, PassengerName, Gender, Age, Parcel, PhoneNo, status, dis):
		self.PNRNo = PNRNo
		self.TrainId = TrainId
		self.PassengerName = PassengerName
		self.Gender = Gender		
		self.Age = Age
		self.Parcel = Parcel
		self.PhoneNo = PhoneNo
		self.status = status
		self.dis = dis
	@app.route('/pasen', methods = ['GET', 'POST'])
	def newpasenger():
		if request.method == 'POST':
			if not request.form['PNRNo'] or not request.form['TrainId'] or not request.form['PassengerName'] or not request.form['Gender'] or not request.form['Age'] or not request.form['Parcel'] or not request.form['PhoneNo'] or not request.form['status'] or not request.form['dis']:
				flash('Please enter all the fields', 'error')
			else:
				passenger = pasregister(request.form['PNRNo'], request.form['TrainId'], request.form['PassengerName'], request.form['Gender'], request.form['Age'], request.form['Parcel'], request.form['PhoneNo'], request.form['status'], request.form['dis'])
				db.session.add(passenger)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('pasen'))
		return render_template('admin.html')
@app.route("/c")
def c():
   return render_template("c.html")
@app.route("/passengerad")
def pasen10():
   return render_template("passengerad.html",pasregister=pasregister.query.all())

@app.route("/value/<id>", methods=['POST','GET'])
def value(id):
	demoo=pasregister.query.get(id)
	demoo.dis=0
	db.session.commit()
	return redirect(url_for("c"))
	
class reservation(db.Model):
	id = db.Column('reserv', db.Integer, primary_key = True)
	
	TrainId = db.Column(db.String(100))
	Coach = db.Column(db.String(100))
	PassengerName = db.Column(db.String(100))
	Source = db.Column(db.String(100))
	Destination = db.Column(db.String(100)) 
	Gender = db.Column(db.String(100))
	Age = db.Column(db.String(30))
	Email = db.Column(db.String(30))
	AdharNo = db.Column(db.String(30))
	PhoneNo = db.Column(db.String(30))
	def __init__(self, TrainId, Coach, PassengerName, Source, Destination, Gender, Age, Email, AdharNo, PhoneNo):
		self.TrainId = TrainId
		self.Coach = Coach
		self.PassengerName = PassengerName
		self.Source = Source
		self.Destination = Destination
		self.Gender = Gender		
		self.Age = Age
		self.Email = Email
		self.AdharNo = AdharNo
		self.PhoneNo = PhoneNo
	@app.route('/reservation', methods = ['GET', 'POST'])
	def reservations():
		if request.method == 'POST':
			if not  request.form['TrainId'] or not request.form['Coach'] or not request.form['PassengerName'] or not request.form['Source'] or not request.form['Destination'] or not request.form['Gender'] or not request.form['Age']  or not request.form['Email']  or not request.form['AdharNo']  or not request.form['PhoneNo']:
				flash('Please enter all the fields', 'error')
			else:
				reserv = reservation(request.form['TrainId'], request.form['Coach'], request.form['PassengerName'], request.form['Source'], request.form['Destination'], request.form['Gender'], request.form['Age'], request.form['Email'], request.form['AdharNo'], request.form['PhoneNo'])
				db.session.add(reserv)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('reservation'))
		return render_template('login.html')


class complaint(db.Model):
	id = db.Column('com', db.Integer, primary_key = True)
	Name = db.Column(db.String(100))
	email = db.Column(db.String(100))
	Fine = db.Column(db.String(100))
	def __init__(self, Name, email, Fine):
		self.Name = Name
		self.email = email
		self.Fine = Fine
	@app.route('/fine', methods = ['GET', 'POST'])
	def compla():
		if request.method == 'POST':
			if not request.form['Name'] or not request.form['email'] or not request.form['Fine']:
				flash('Please enter all the fields', 'error')
			else:
				com = complaint(request.form['Name'], request.form['email'], request.form['Fine'])
				db.session.add(com)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('fine'))
		return render_template('newlogin.html')
class onlinebook(db.Model):
	id = db.Column('on', db.Integer, primary_key = True)
	Name = db.Column(db.String(100))
	Gender = db.Column(db.String(100))
	Source = db.Column(db.String(80))
	Destination = db.Column(db.String(30))
	Date= db.Column(db.String(30))
	AdharNo= db.Column(db.String(30))
	PassengerNo = db.Column(db.String(30))
	def __init__(self, Name, Gender, Source, Destination, Date, AdharNo, PassengerNo):
		self.Name = Name
		self.Gender = Gender
		self.Source = Source
		self.Destination = Destination
		self.Date = Date
		self.AdharNo = AdharNo
		self.PassengerNo = PassengerNo
	@app.route('/payment', methods = ['GET', 'POST'])
	def payment():
		if request.method == 'POST':
			if not request.form['Name'] or not request.form['Gender'] or not request.form['Source'] or not request.form['Destination'] or not request.form['Date'] or not request.form['AdharNo'] or not request.form['PassengerNo']:
				flash('Please enter all the fields', 'error')
			else:
				on = onlinebook(request.form['Name'], request.form['Gender'], request.form['Source'], request.form['Destination'], request.form['Date'], request.form['AdharNo'], request.form['PassengerNo'])
				db.session.add(on)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('payment'))
		return render_template('payment.html')
class elinebook1(db.Model):
	id = db.Column('on1', db.Integer, primary_key = True)
	Name = db.Column(db.String(100))
	Gender = db.Column(db.String(100))
	Source = db.Column(db.String(80))
	Destination = db.Column(db.String(30))
	Date= db.Column(db.String(30))
	Adharno= db.Column(db.String(30))
	PassengerNo = db.Column(db.String(30))
	def __init__(self, Name, Gender, Source, Destination, Date, AdharNo, PassengerNo):
		self.Name = Name
		self.Gender = Gender
		self.Source = Source
		self.Destination = Destination
		self.Date = Date
		self.AdharNo = AdharNo
		self.PassengerNo = PassengerNo
	@app.route('/payment', methods = ['GET', 'POST'])
	def payment1():
		if request.method == 'POST':
			if not request.form['Name'] or not request.form['Gender'] or not request.form['Source'] or not request.form['Destination'] or not request.form['Date'] or not request.form['AdharNo'] or not request.form['PassengerNo']:
				flash('Please enter all the fields', 'error')
			else:
				on1 = elinebook1(request.form['Name'], request.form['Gender'], request.form['Source'], request.form['Destination'], request.form['Date'],  request.form['AdharNo'],request.form['PassengerNo'])
				db.session.add(on1)
				db.session.commit()
				flash('Record was successfully') 
				return redirect(url_for('payment'))
		return render_template('payment.html')
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)

