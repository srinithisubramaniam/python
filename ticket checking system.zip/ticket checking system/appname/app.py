from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:kgisl@localhost/ticketchecking'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)
class login(db.Model):
   id = db.Column('login_id', db.Integer, primary_key = True)
   UserName = db.Column(db.String(100))
   Password = db.Column(db.String(50))
   
def __init__(self, UserName, Password):
   self.UserName = UserName
   self.Password= Password
   
@app.route('/new', methods = ['GET', 'POST'])
def new():
   if request.method == 'POST':
      if not request.form['UserName'] or not request.form['Password']:
         flash('Please enter all the fields', 'error')
      else:
         logic = login(request.form['UserName'], request.form['Password'])
         db.session.add(logic)
         db.session.commit()
         flash('Record was successfully added')
         return redirect(url_for('show_all'))
   return render_template('new.html')

if __name__ == '__main__':
   db.create_all()
   app.run(debug = True)
