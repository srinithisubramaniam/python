from flask import Flask, render_template
app = Flask(__name__)
@app.route("/")
def index():
   return render_template("index.html")
@app.route("/a")
def selection():
   return render_template("selection.html")
@app.route("/b")
def ttr():
   return render_template("ttr.html")
@app.route("/c")
def ttrview():
   return render_template("ttrview.html")
@app.route("/d")
def check():
   return render_template("check.html")
@app.route("/e")
def checkdetail():
   return render_template("checkdetail.html")
@app.route("/f")
def allview():
   return render_template("allview.html")
@app.route("/g")
def inspector():
   return render_template("inspector.html")
@app.route("/h")
def insview():
   return render_template("insview.html")   
@app.route("/i")
def chief():
   return render_template("chief.html")
@app.route("/j")
def chiefview():
   return render_template("chiefview.html")
@app.route("/k")
def minister():
   return render_template("minister.html")
@app.route("/l")
def ministerview():
   return render_template("ministerview.html")
@app.route("/m")
def third():
   return render_template("third.html")
if __name__ == '__main__':
   app.run(debug = True)
